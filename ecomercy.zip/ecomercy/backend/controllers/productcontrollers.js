const express = require('express');
const router = express.Router();
const Product = require('../models/Product');

// Get all products with optional category filter
router.get('/', async (req, res) => {
  try {
    let query = {};
    if (req.query.categoryId) {
      query.category = req.query.categoryId;
    }
    const products = await Product.find(query).populate('category supplier');
    res.json(products);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Create new product
router.post('/', async (req, res) => {
  const product = new Product({
    name: req.body.name,
    description: req.body.description,
    price: req.body.price,
    stock: req.body.stock,
    category: req.body.categoryId,
    supplier: req.body.supplierId
  });

  try {
    const newProduct = await product.save();
    res.status(201).json(newProduct);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

module.exports = router;
