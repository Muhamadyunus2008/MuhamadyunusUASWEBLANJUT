const mongoose = require('mongoose');

const supplierSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true,
    unique: true
  },
  phone: String,
  address: String,
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Virtual for product relationship
supplierSchema.virtual('products', {
  ref: 'Product',
  localField: '_id',
  foreignField: 'supplier'
});

module.exports = mongoose.model('Supplier', supplierSchema);
