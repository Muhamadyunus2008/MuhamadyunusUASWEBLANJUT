require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

// Import controllers
const categoryController = require('./controllers/categoryController');
const productController = require('./controllers/productController');
const supplierController = require('./controllers/supplierController');
const transactionController = require('./controllers/transactionController');

const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Database connection
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost/ecommerce-mvc', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});
mongoose.connection.on('connected', () => {
  console.log('Connected to MongoDB');
});
mongoose.connection.on('error', (err) => {
  console.log('MongoDB connection error: ' + err);
});

// API Routes
app.use('/api/categories', categoryController);
app.use('/api/products', productController);
app.use('/api/suppliers', supplierController);
app.use('/api/transactions', transactionController);

// Serve static files (frontend)
if (process.env.NODE_ENV === 'production') {
  app.use(express.static('../frontend'));
  app.get('*', (req, res) => {
    res.sendFile(path.resolve(__dirname, '../frontend', 'index.html'));
  });
}

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: 'Something went wrong!' });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
